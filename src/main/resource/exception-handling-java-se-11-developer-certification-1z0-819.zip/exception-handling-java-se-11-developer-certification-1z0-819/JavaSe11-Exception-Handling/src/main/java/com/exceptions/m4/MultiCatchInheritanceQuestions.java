package com.exceptions.m4;

import java.io.FileNotFoundException;
import java.io.IOException;

public class MultiCatchInheritanceQuestions {

    public static void main(String[] args) {

//        // doesn't compile
//        try {
//            throw new IOException();
//        } catch (FileNotFoundException | IOException e) {
//
//        }
//
//        // doesn't compile
//        try {
//            throw new IOException();
//        } catch (Exception | IOException e) {
//
//        }
//
//        try {
//            throw new IOException();
//        } catch (RuntimeException | IOException e) {
//
//        }

    }
}
