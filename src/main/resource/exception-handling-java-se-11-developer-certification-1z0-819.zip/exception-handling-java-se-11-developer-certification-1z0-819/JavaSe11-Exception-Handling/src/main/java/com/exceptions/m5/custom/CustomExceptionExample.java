package com.exceptions.m5.custom;

import javax.xml.crypto.Data;
import java.io.IOException;
import java.sql.Connection;

public class CustomExceptionExample {

    public static void main(String[] args) {

        throw new CustomException("");
    }
}
