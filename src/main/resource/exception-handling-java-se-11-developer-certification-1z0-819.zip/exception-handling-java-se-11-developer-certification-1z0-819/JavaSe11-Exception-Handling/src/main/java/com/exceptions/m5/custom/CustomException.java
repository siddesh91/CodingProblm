package com.exceptions.m5.custom;

public class CustomException extends RuntimeException {

    public CustomException(String msg) {
        super(msg);
    }
}
