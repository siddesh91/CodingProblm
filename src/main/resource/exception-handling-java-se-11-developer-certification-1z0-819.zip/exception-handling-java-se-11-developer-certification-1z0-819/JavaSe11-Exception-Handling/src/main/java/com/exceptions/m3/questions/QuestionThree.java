package com.exceptions.m3.questions;

import java.io.FileInputStream;
import java.io.FileOutputStream;

public class QuestionThree {

    // TWR with a comma instead of a semicolon
    public static void main(String[] args) {

//        try (var in = new FileInputStream("in.txt"),
//                var out = new FileOutputStream("out.txt")) {
//        } catch (IllegalArgumentException | IOException e) {
//
//        }
    }
}
