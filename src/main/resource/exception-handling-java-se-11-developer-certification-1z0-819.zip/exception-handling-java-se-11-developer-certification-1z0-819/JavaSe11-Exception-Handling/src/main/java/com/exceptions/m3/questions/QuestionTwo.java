package com.exceptions.m3.questions;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class QuestionTwo {

    // invalid multi-catch
    public static void main(String[] args) {

//        try (var in = new FileInputStream("in.txt")) {
//            // read the input
//        } catch (FileNotFoundException | IOException e) {
//            // handle
//        }
    }
}
