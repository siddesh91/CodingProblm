package com.exceptions.m5.overriding;

import java.io.IOException;

public class Parent {

    void doThing() throws IOException {
    }

}
