package m2.v2_Boolean.after;
import static java.lang.System.out;

public class PrimitiveBooleans {
    public static void main(String[] args) {
        out.println("\n** Primitive booleans ** \n");

        boolean flag = true;
        flag = false;

        int value = flag ? 1 : -1;

    }
}
