package m2.v8_Number_Systems.before;
import static java.lang.System.out;

public class NumberSystems {
    public static void main(String[] args) {
        out.println("\n** Alternative Number Systems ** \n");


    }
}
