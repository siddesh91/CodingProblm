package m2.v9_Scientific_Notation.before;
import static java.lang.System.out;

public class ScientificNotation {
    public static void main(String[] args) {
        out.println("\n** Scientific Notation ** \n");


    }
}
