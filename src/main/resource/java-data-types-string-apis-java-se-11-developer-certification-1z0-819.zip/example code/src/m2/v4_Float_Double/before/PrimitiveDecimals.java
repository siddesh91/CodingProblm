package m2.v4_Float_Double.before;
import static java.lang.System.out;

public class PrimitiveDecimals {

    public static void main(String[] args) {
        out.println("\n** Primitive Decimals ** \n");



    }
}
