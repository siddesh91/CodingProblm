package m2.v3_Byte_Short_Int_Long.before;
import static java.lang.System.out;

public class PrimitiveIntegrals {

    public static void main(String[] args) {
        out.println("\n** Primitive Integrals ** \n");


    }
}
