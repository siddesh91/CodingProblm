package m2.v7_Underscores.before;
import static java.lang.System.out;

public class  Underscores {
    public static void main(String[] args) {
        out.println("\n** Underscores in Numbers ** \n");



    }
}
