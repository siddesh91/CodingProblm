package m2.v5_Char.before;
import static java.lang.System.out;

public class PrimitiveChars {
    public static void main(String[] args) {
        out.println("\n** Primitive chars ** \n");



    }
}
