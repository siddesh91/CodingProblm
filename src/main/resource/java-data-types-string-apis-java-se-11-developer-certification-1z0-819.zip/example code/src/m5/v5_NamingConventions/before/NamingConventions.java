package m5.v5_NamingConventions.before;
import static java.lang.System.out;

public class NamingConventions {

    public static void main(String[] args) {
        out.println("\n** Variable Naming Conventions ** \n");
    }
}
