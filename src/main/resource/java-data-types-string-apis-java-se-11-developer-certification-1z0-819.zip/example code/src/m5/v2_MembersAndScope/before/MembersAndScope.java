package m5.v2_MembersAndScope.before;
import static java.lang.System.out;

public class MembersAndScope {

    public static void main(String[] args) {
        out.println("\n** Members and Scope ** \n");

    }
}
