package m5.v4_NamingRules.before;
import static java.lang.System.out;

public class NamingRules {

    public static void main(String[] args) {
        out.println("\n** Variable Naming Rules ** \n");
    }
}
