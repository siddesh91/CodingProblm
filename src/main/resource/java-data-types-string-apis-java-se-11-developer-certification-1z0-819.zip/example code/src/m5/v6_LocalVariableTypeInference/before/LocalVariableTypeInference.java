package m5.v6_LocalVariableTypeInference.before;
import static java.lang.System.out;

public class LocalVariableTypeInference {

    public static void main(String[] args) {
        out.println("\n** Local Variable Type Inference ** \n");


    }

}
