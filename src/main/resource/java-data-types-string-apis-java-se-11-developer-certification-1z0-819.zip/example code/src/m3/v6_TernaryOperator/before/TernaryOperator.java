package m3.v6_TernaryOperator.before;
import static java.lang.System.out;

public class TernaryOperator {
    public static void main(String[] args) {
        out.println("\n** Ternary Operator ** \n");

    }
}
