package m3.v1_Arithmetic_Operators.before;
import static java.lang.System.out;

public class ArithmeticOperators {
    public static void main(String[] args) {
        out.println("\n** Arithmetic Operators ** \n");


    }
}
