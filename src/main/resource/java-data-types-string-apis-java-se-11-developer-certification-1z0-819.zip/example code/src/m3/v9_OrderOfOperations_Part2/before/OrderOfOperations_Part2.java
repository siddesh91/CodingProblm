package m3.v9_OrderOfOperations_Part2.before;
import static java.lang.System.out;

public class OrderOfOperations_Part2 {
    public static void main(String[] args) {
        out.println("\n** Order of Operations: Part 2 ** \n");

    }
}
