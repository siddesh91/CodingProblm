package m3.v10_OrderOfOperations_Part3.before;
import static java.lang.System.out;

public class OrderOfOperations_Part3 {

    public static void main(String[] args) {
        out.println("\n** Order of Operations: Part 3 ** \n");

    }
}
