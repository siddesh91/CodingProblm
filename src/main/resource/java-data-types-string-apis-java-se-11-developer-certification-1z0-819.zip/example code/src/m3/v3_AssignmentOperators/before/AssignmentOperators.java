package m3.v3_AssignmentOperators.before;
import static java.lang.System.out;

public class AssignmentOperators {
    public static void main(String[] args) {
        out.println("\n** Assignment Operators ** \n");


    }
}
