package m3.v7_OtherOperators.before;
import static java.lang.System.out;

public class OtherOperators {
    public static void main(String[] args) {
        out.println("\n** Other Operators ** \n");

    }
}
