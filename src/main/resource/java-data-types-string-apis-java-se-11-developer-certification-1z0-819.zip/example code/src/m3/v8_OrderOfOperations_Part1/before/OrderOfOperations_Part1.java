package m3.v8_OrderOfOperations_Part1.before;
import static java.lang.System.out;

public class OrderOfOperations_Part1 {
    public static void main(String[] args) {
        out.println("\n** Other Operators ** \n");

    }
}
