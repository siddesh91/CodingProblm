package m3.v11_MathAPIs.before;
import static java.lang.System.out;

public class MathAPIs {

    public static void main(String[] args) {
        out.println("\n** Math APIs ** \n");



    }
}
