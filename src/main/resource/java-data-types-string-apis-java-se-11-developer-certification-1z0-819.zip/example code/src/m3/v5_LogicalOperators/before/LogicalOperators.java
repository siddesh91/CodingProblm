package m3.v5_LogicalOperators.before;
import static java.lang.System.out;

public class LogicalOperators {
    public static void main(String[] args) {
        out.println("\n** Logical Operators ** \n");


    }
}
