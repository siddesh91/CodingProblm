package m3.v4_RelationalOperators.before;
import static java.lang.System.out;

public class RelationalOperators {
    public static void main(String[] args) {
        out.println("\n** Relational Operators ** \n");

    }
}
