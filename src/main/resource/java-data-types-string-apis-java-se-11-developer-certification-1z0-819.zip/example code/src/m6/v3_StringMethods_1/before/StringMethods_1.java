package m6.v3_StringMethods_1.before;
import static java.lang.System.out;

public class StringMethods_1 {

    public static void main(String [] args) {
        
        out.println("\n** String Methods, Part 1 ** \n");



    }
}
