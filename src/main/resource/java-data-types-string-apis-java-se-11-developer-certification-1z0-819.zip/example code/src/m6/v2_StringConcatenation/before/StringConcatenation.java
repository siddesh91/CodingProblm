package m6.v2_StringConcatenation.before;
import static java.lang.System.out;

public class StringConcatenation {

    public static void main(String [] args) {

        out.println("\n** String Concatenation ** \n");

    }
}
