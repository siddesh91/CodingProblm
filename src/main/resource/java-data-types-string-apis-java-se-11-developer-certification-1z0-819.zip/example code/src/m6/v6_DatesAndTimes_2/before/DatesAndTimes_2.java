package m6.v6_DatesAndTimes_2.before;
import static java.lang.System.out;

import java.time.*;
import java.time.format.DateTimeFormatter;

public class DatesAndTimes_2 {

    public static void main(String[] args) {

        out.println("\n** Dates and Times, Part 2 ** \n");

        

    }
}
