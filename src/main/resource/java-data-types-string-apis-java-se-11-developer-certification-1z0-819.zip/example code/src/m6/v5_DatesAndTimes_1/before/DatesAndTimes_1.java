package m6.v5_DatesAndTimes_1.before;
import static java.lang.System.out;

public class DatesAndTimes_1 {

    public static void main(String[] args) {

        out.println("\n** Dates and Times, Part 1 ** \n");

    }
}
