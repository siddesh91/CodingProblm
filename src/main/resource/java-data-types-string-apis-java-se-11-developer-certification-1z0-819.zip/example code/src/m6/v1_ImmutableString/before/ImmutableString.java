package m6.v1_ImmutableString.before;

import static java.lang.System.out;

public class ImmutableString {
    public static void main(String [] args) {

        out.println("\n** Immutable Strings ** \n");

    }
}
