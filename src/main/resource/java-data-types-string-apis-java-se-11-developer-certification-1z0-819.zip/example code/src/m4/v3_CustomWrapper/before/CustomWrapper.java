package m4.v3_CustomWrapper.before;
import static java.lang.System.out;

public class CustomWrapper {

    public static void main(String[] args) {
        out.println("\n** Custom Wrapper ** \n");

    }
}
