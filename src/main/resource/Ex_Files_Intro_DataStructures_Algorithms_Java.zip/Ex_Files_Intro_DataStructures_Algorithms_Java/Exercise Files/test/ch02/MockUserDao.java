package ch02;

import chapter2.User;
import chapter2.UserDao;

public class MockUserDao implements UserDao{
	
	@Override
	public User findUserByEmail(String email) {
		// TODO Auto-generated method stub
		return null;
	}

}
