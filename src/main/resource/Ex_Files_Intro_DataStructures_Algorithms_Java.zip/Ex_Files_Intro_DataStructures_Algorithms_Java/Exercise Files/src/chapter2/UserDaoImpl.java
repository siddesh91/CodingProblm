package chapter2;

public class UserDaoImpl implements UserDao {

	@Override
	public User findUserByEmail(String email) {
		// this guy makes a connection to a DB 
		// and gets the user object
		return null;
	}

}
