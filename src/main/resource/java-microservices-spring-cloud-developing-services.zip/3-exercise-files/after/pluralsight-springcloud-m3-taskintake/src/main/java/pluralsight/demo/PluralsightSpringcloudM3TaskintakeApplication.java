package pluralsight.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PluralsightSpringcloudM3TaskintakeApplication {

	public static void main(String[] args) {
		SpringApplication.run(PluralsightSpringcloudM3TaskintakeApplication.class, args);
	}
}
